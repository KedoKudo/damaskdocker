# -*- coding: UTF-8 no BOM -*-

"""Test functionality"""

from .test import Test      # noqa
