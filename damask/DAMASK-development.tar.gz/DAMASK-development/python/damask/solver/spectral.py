# -*- coding: UTF-8 no BOM -*-


from .solver import Solver

class Spectral(Solver):

  def __init__(self):
    self.solver='Spectral'
