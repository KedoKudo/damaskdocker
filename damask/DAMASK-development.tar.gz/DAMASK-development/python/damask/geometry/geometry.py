# -*- coding: UTF-8 no BOM -*-


import damask.geometry

class Geometry():
  """
  General class for geometry parsing.

  Sub-classed by the individual solvers.
  """
  
  def __init__(self,solver=''):
    solverClass = {
                      'spectral': damask.geometry.Spectral,
                      'marc':     damask.geometry.Marc,
                    }
    if solver.lower() in list(solverClass.keys()):
      self.__class__=solverClass[solver.lower()]
      self.__init__()

