# -*- coding: UTF-8 no BOM -*-


from .geometry import Geometry

class Marc(Geometry):

  def __init__(self):
    self.solver='Marc'
