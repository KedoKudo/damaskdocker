# -*- coding: UTF-8 no BOM -*-

"""Aggregator for configuration file handling"""

from .material import Material    # noqa
